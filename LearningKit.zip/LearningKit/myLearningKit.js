/* 23w 1012 JS files */
function p01Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p>Chess is a board game for two players. It is sometimes called Western chess or international chess. The current form of the game emerged in Spain and the rest of Southern Europe during the second half of the 15th century after evolving from chaturanga, a similar but much older game of Indian origin.</p>";
  /* in Ex1, set message text and image sources for problem01*/
  var im=document.getElementById("flowchart");
  im.src="images/Chess/ChessSet.jpg";
  var im1=document.getElementById("another");
  im1.src="images/Chess/chess-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/Chess/park-chess.jpg";
 
  /* the following three lines gets the checkboxes, and unchecks them
  */
  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
  /* in Ex3, update display of images */


}


/* in Ex2, uncomment the following function and complete it*/


function checkUncheck1(){
  if (document.getElementById("check1").checked==true) {
     // add a getElementById here to get "flowchart" img and 
     document.getElementById("flowchart").style.display="inline";
     // set the display property of its style to one of "inline" or "none"	 

	 
  }
  else {
   document.getElementById("flowchart").style.display="none";
     // add a getElementById here to get "flowchart" img and 
     // set the display property of its style to one of "inline" or "none"	 
	  
	  
  }
}



function checkUncheck2(){
  if (document.getElementById("check2").checked==true) {
     // add a getElementById here to get "js" img and 
     // set the display property of its style  
	  document.getElementById("js").style.display="inline";
	 
  }
  else {
     // add a getElementById here to get "js" img and 
     // set the display property of its style  
	  
     document.getElementById("js").style.display="none";
  }
}

function checkUncheck3(){
   if (document.getElementById("check3").checked==true) {
      // add a getElementById here to get "js" img and 
      // set the display property of its style  
      document.getElementById("another").style.display="inline";
     
   }
   else {
      // add a getElementById here to get "js" img and 
      // set the display property of its style  
      
      document.getElementById("another").style.display="none";
   }
 }
 
/* in Ex2, you need to create function
   checkUncheck3, which is similar to checkUncheck 1 and 2
*/

function p02Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p>Go is an abstract strategy board game for two players in which the aim is to surround more territory than the opponent. The game was invented in China more than 2,500 years ago and is believed to be the oldest board game continuously played to the present day.</p>";
  /* in Ex1, set message text and image sources for problem01*/
  var im=document.getElementById("flowchart");
  im.src="images/Go/800px-Go.jpg";
  var im1=document.getElementById("another");
  im1.src="images/Go/go-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/Go/alphaGo.jpg";



  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";

}
/* in Ex3, create function p02Func similar to p01Func */
function zoomIn() {
   document.getElementById("flowchart").style.width ="200%";
   document.getElementById("js").style.width ="200%";
   document.getElementById("another").style.width ="200%";
}
function zoomOut() {
   document.getElementById("flowchart").style.width ="100%";
   document.getElementById("js").style.width="100%";
   document.getElementById("another").style.width ="100%";
}
/* in Ex4, create functions zoomIn() and zoomOut() */
function p03Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p>A game in which two opposing teams of 11 players each defend goals at opposite ends of a field having goal posts at each end, with points being scored chiefly by carrying the ball across the opponent's goal line and by place-kicking or drop-kicking the ball over the crossbar between the opponent's goal posts.</p>";
  
  var im=document.getElementById("flowchart");
  im.src="images/ball/football.jpg";
  var im1=document.getElementById("another");
  im1.src="images/ball/ball-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/ball/goalball.jpg";



  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";

}
function p04Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> A fast contact sport played on an ice rink between two teams of six skaters, who attempt to drive a small rubber disk (the puck) into the opposing goal with hooked or angled sticks.</p>";
  
  var im=document.getElementById("flowchart");
  im.src="images/hockey/icehockey.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/hockey/fieldhockey.jpg";



  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";


}

function p05Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart for a computer program to receive two numbers and output the larger one if they are not equal, and output “they are equal”</p>";
  
  var im=document.getElementById("flowchart");
  im.src="images/lk5/fw5.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk5/js5.png";


  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";

}
function p06Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart for a computer program to receive two whole numbers as sides of a rectangle and output  the rectangle’s perimeter, in the form of “Perimeter: x” where x is the perimeter. ”</p>";
  
  var im=document.getElementById("flowchart");
  im.src="images/lk6/fw6.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk6/js6.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p07Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart for a computer program to receive three whole numbers and store them in memory spaces called a, b, and c as three semi-axes of an ellipsoid, and calculate and output the volume of this   ellipsoid, in the form of “volume: x” where x is the volume.” </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk7/fw7.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk7/js7.png";
  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p08Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart for a computer program to receive three real numbers and store them in memory spaces called a, b, and c, and return the largest number of the three, in the form of “largest: x” where  x is the largest value. </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk8/fw8.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk8/js8.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p09Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart to receive three numerical coefficients of a quadratic equation and determines if it has two distinct real roots, one root, or no roots in real numbers, output “it has 2 distinct roots”, “its roots are identical”, “it has no roots in real numbers” respectively </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk9/fw9.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk9/js9.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p10Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart for the function, that receives a number, and first checks whether the input is divisible by 6 or not, outputting “divisible by 6” or “not divisible by 6”, respectively.  </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk10/fw10.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk10/js10.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p11Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart to receive a number from 0~100, and map it to a letter grade based on Yorku standard.Using if-else statements </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk11/fw11.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk11/js11.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}
function p12Func() {
   
	var p1= document.getElementById("problem");
   p1.innerHTML="<p> a flowchart to receive a number from 0~100, and map it to a letter grade based on Yorku standard.Using case </p>";
  var im=document.getElementById("flowchart");
  im.src="images/lk12/fw12.jpg";
  var im1=document.getElementById("another");
  im1.src="images/hockey/hockey-another.jpg";
  var im3=document.getElementById("js");
  im3.src="images/lk12/js12.png";

  document.getElementById("check1").checked=false;
  document.getElementById("check2").checked=false;
  document.getElementById("check3").checked=false;
  document.getElementById("flowchart").style.display="none";
  document.getElementById("js").style.display="none";
  document.getElementById("another").style.display="none";
}

